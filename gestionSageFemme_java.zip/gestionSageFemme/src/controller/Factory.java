/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.event.*;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
import modele.*;
import controller.*;
import gestionsagefemme.*;
import java.util.Date;
import java.time.*;
import java.time.format.DateTimeFormatter;
import com.toedter.calendar.JDateChooser;
/**
 *
 * @author rumariza
 */
public class Factory {
    private static Connection conn = null;
    private static Statement stm;
    private static PreparedStatement pstmet=null;
    private static ResultSet rs=null;
    
    public static Connection getConnection(){
        String serveur="localhost";
        int port=3306;
        String database="gestion_de_centre_de_sante_sage_femme";
        String username="root";
        String password="";
        
        try{
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            String url="jdbc:mysql://" +serveur+":"+port+"/"+database;
            conn=DriverManager.getConnection(url, username, password);
            System.out.println("connected");
            return conn;
        } catch(Exception e){
            System.out.println("ERREUR");
            e.printStackTrace();
            return null;
            
        }
        
    }
    
    public static void SeConnecter(String nom,String pass){
        try{
            conn=getConnection();
            stm=conn.createStatement();
            rs=stm.executeQuery("select * from gestion_de_centre_de_sante_sage_femme.utilisateur where username = '"+ nom+"' and mot_de_passe = '"+pass+"'");
        }catch(Exception e){
            JOptionPane.showConfirmDialog(null,e.getMessage());

        }
    }
//                ===============
//                    PATIENT
//                ===============
    public static void insererPat(Patient pat){
        try{
            conn=getConnection();
            pstmet=conn.prepareStatement("insert into gestion_de_centre_de_sante_sage_femme.patient"
                    + "(ID_PATIENT,NOM_PATIENT, PRENOM_PATIENT, DATE, ADRESSE, TEL, SEXE) values(?,?,?,?,?,?,?)");
            pstmet.setInt(1,pat.getId());
            pstmet.setString(2,pat.getNom());
            pstmet.setString(3,pat.getPrenom());
            pstmet.setString(4,String.valueOf(pat.getDatee()));
            pstmet.setString(5,pat.getadresse());
            pstmet.setInt(6,pat.getTel());
            pstmet.setString(7,pat.getSexe());
            pstmet.executeUpdate();
            conn.close();
        }catch(Exception e){
            JOptionPane.showConfirmDialog(null,e.getMessage());
        }
    }
    public static ArrayList<Patient> AfficherPat(){
        ArrayList<Patient> list_pat=new ArrayList();
        Patient pat =null;
        try{
            conn=getConnection();
            stm=conn.createStatement();
            rs=stm.executeQuery("select * from gestion_de_centre_de_sante_sage_femme.patient");
            while(rs.next()){
                pat=new Patient();
                pat.setId(rs.getInt("ID_PATIENT"));
                pat.setNom(rs.getString("NOM_PATIENT"));
                pat.setPrenom(rs.getString("PRENOM_PATIENT"));
                pat.setDate(rs.getDate("DATE"));
                pat.setadresse(rs.getString("ADRESSE"));
                pat.setTel(rs.getInt("TEL"));
                pat.setSexe(rs.getString("SEXE"));
                list_pat.add(pat);
            }
            conn.close();
            stm.close();
        }catch(Exception e){
            JOptionPane.showConfirmDialog(null,e.getMessage());
        }return list_pat;
    }
    public static void SupprimerPat(Patient pat){
        try{
            conn = getConnection();
            stm = conn.createStatement();
            String delete="delete from gestion_de_centre_de_sante_sage_femme.patient where ID_PATIENT = '"+pat.getId()+"'";
            stm.executeUpdate(delete);
        }catch (Exception e){
            JOptionPane.showConfirmDialog(null, e.getMessage());
        }
    
    }
    public static void ModifierPat(Patient pat, int a){
        try{
            conn=getConnection();
            pstmet=conn.prepareStatement("update gestion_de_centre_de_sante_sage_femme.patient SET NOM_PATIENT=?, PRENOM_PATIENT=?, DATE=?, ADRESSE=?, TEL=?, SEXE=? where ID_PATIENT='"+a+"'");
            
            pstmet.setString(1,pat.getNom());
            pstmet.setString(2,pat.getPrenom());
            pstmet.setString(3,String.valueOf(pat.getDatee()));
            pstmet.setString(4,pat.getadresse());
            pstmet.setInt(5,pat.getTel());
            pstmet.setString(6,pat.getSexe());
            pstmet.executeUpdate();
            conn.close();
        }catch(Exception e){
            JOptionPane.showConfirmDialog(null, e.getMessage());
        }
    }
    public static Patient RechercherPat(int a){
        Patient pat = null;
        try{
            conn=getConnection();
            stm=conn.createStatement();
            rs=stm.executeQuery("select * from gestion_de_centre_de_sante_sage_femme.patient where ID_PATIENT='"+a+"'");
            while(rs.next()){
                pat = new Patient();
                pat.setId(rs.getInt("ID_PATIENT"));
                pat.setNom(rs.getString("NOM_PATIENT"));
                pat.setPrenom(rs.getString("PRENOM_PATIENT"));
                pat.setDate(rs.getDate("DATE"));
                pat.setadresse(rs.getString("ADRESSE"));
                pat.setTel(rs.getInt("TEL"));
                pat.setSexe(rs.getString("SEXE"));
            }
            conn.close();
            stm.close();
            return pat;
        }catch(Exception e){
            return null;
        }
    }
//                  ===============
//                     PHARMACIE
//                  ===============
    public static void insererPha(Pharmacie pha){
        try{
            conn=getConnection();
            pstmet=conn.prepareStatement("insert into gestion_de_centre_de_sante_sage_femme.pharmacie"
                    + "(ID_MEDICAMENT,NOM_MEDICAMENT, MALADIE, DATE_FABRICATION, DATE_EXPIRATION) values(?,?,?,?,?)");
            pstmet.setInt(1,pha.getId());
            pstmet.setString(2,pha.getNom_medi());
            pstmet.setString(3,pha.getMaladie());
            pstmet.setString(4,String.valueOf(pha.getDate_fab()));
            pstmet.setString(5,String.valueOf(pha.getDate_exp()));
            
            pstmet.executeUpdate();
            conn.close();
        }catch(Exception e){
            JOptionPane.showConfirmDialog(null,e.getMessage());
        }
    }
    public static ArrayList<Pharmacie> AfficherPha(){
        ArrayList<Pharmacie> list_pha=new ArrayList();
        Pharmacie pha =null;
        try{
            conn=getConnection();
            stm=conn.createStatement();
            rs=stm.executeQuery("select * from gestion_de_centre_de_sante_sage_femme.pharmacie");
            while(rs.next()){
                pha=new Pharmacie();
                pha.setId(rs.getInt("ID_MEDICAMENT"));
                pha.setNom_medi(rs.getString("NOM_MEDICAMENT"));
                pha.setMaladie(rs.getString("MALADIE"));
                pha.setDate_fab(rs.getDate("DATE_FABRICATION"));
                pha.setDate_exp(rs.getDate("DATE_EXPIRATION"));
                
                list_pha.add(pha);
            }
            conn.close();
            stm.close();
        }catch(Exception e){
            JOptionPane.showConfirmDialog(null,e.getMessage());
        }return list_pha;
    }
    public static void SupprimerPha(Pharmacie pha){
        try{
            conn = getConnection();
            stm = conn.createStatement();
            String delete="delete from gestion_de_centre_de_sante_sage_femme.pharmacie where ID_MEDICAMENT = '"+pha.getId()+"'";
            stm.executeUpdate(delete);
        }catch (Exception e){
            JOptionPane.showConfirmDialog(null, e.getMessage());
        }
    
    }
    public static void ModifierPha(Pharmacie pha, int a){
        try{
            conn=getConnection();
            pstmet=conn.prepareStatement("update gestion_de_centre_de_sante_sage_femme.patient SET NOM_MEDICAMENT=?, MALADIE=?, DATE_FABRICATION=?, DATE_EXPIRATION=? where ID_MEDICAMENT='"+a+"'");
            
            pstmet.setString(1,pha.getNom_medi());
            pstmet.setString(2,pha.getMaladie());
            pstmet.setString(3,String.valueOf(pha.getDate_fab()));
            pstmet.setString(4,String.valueOf(pha.getDate_exp()));
            
            pstmet.executeUpdate();
            conn.close();
        }
        catch(Exception e){
            JOptionPane.showConfirmDialog(null, e.getMessage());
        }
    }
    public static Pharmacie RechercherPha(int a){
        Pharmacie pha = null;
        try{
            conn=getConnection();
            stm=conn.createStatement();
            rs=stm.executeQuery("select * from gestion_de_centre_de_sante_sage_femme.pharmacie where ID_MEDICAMENT='"+a+"'");
            while(rs.next()){
                pha = new Pharmacie();
                pha.setId(rs.getInt("ID_MEDICAMENT"));
                pha.setNom_medi(rs.getString("NOM_PATIENT"));
                pha.setMaladie(rs.getString("PRENOM_PATIENT"));
                pha.setDate_fab(rs.getDate("DATE_FABRICATION"));
                pha.setDate_exp(rs.getDate("DATE_EXPIRATION"));
                
            }
            conn.close();
            stm.close();
            return pha;
        }catch(Exception e){
            return null;
        }
    }
//                   ================
//                      SAGE-FEMME
//                   ================
    public static void insererSag(SageFemme sag){
        try{
            conn=getConnection();
            pstmet=conn.prepareStatement("insert into gestion_de_centre_de_sante_sage_femme.sage_femme"
                    + "(ID_SAGE_FEMME,NOM, PRENOM, DATE_NAISSANCE, ADRESSE, TEL, SPECIALITE) values(?,?,?,?,?,?,?)");
            pstmet.setInt(1,sag.getId());
            pstmet.setString(2,sag.getNom());
            pstmet.setString(3,sag.getPrenom());
            pstmet.setString(4,String.valueOf(sag.getDate_naiss()));
            pstmet.setString(5,sag.getAdresse());
            pstmet.setInt(6,sag.gettel());
            pstmet.setString(7,sag.getSpecialite());

            
            pstmet.executeUpdate();
            conn.close();
        }catch(Exception e){
            JOptionPane.showConfirmDialog(null,e.getMessage());
        }
    }
    public static ArrayList<SageFemme> AfficherSag(){
        ArrayList<SageFemme> list_sag=new ArrayList();
        SageFemme sag =null;
        try{
            conn=getConnection();
            stm=conn.createStatement();
            rs=stm.executeQuery("select * from gestion_de_centre_de_sante_sage_femme.sage_femme");
            while(rs.next()){
                sag=new SageFemme();
                sag.setId(rs.getInt("ID_SAGE_FEMME"));
                sag.setNom(rs.getString("NOM"));
                sag.setPrenom(rs.getString("PRENOM"));
                sag.setDate_naiss(rs.getDate("DATE_NAISSANCE"));
                sag.setAdresse(rs.getString("ADRESSE"));
                sag.settel(rs.getInt("TEL"));
                sag.setSpecialite(rs.getString("SPECIALITE"));
                
                list_sag.add(sag);
            }
            conn.close();
            stm.close();
        }catch(Exception e){
            JOptionPane.showConfirmDialog(null,e.getMessage());
        }return list_sag;
    }
    public static void SupprimerSag(SageFemme sag){
        try{
            conn = getConnection();
            stm = conn.createStatement();
            String delete="delete from gestion_de_centre_de_sante_sage_femme.sage_femme where ID_SAGE_FEMME = '"+sag.getId()+"'";
            stm.executeUpdate(delete);
        }catch (Exception e){
            JOptionPane.showConfirmDialog(null, e.getMessage());
        }
    
    }
    public static void ModifierSag(SageFemme sag, int a){
        try{
            conn=getConnection();
            pstmet=conn.prepareStatement("update gestion_de_centre_de_sante_sage_femme.sage_femme SET NOM=?, PRENOM=?, DATE_NAISSANCE=?, ADRESSE=?, TEL=?,SPECIALITE=? where ID_SAGE_FEMME='"+a+"'");
            
            pstmet.setString(1,sag.getNom());
            pstmet.setString(2,sag.getPrenom());
            pstmet.setString(3,String.valueOf(sag.getDate_naiss()));
            pstmet.setString(4,sag.getAdresse());            
            pstmet.setInt(5,sag.gettel());
            pstmet.setString(6,sag.getSpecialite());

            
            pstmet.executeUpdate();
            conn.close();
        }
        catch(Exception e){
            JOptionPane.showConfirmDialog(null, e.getMessage());
        }
    }
    public static SageFemme RechercherSag(int a){
        SageFemme sag = null;
        try{
            conn=getConnection();
            stm=conn.createStatement();
            rs=stm.executeQuery("select * from gestion_de_centre_de_sante_sage_femme.sage_femme where ID_SAGE_FEMME='"+a+"'");
            while(rs.next()){
                sag = new SageFemme();
//                sag.setId(rs.getInt("ID_SAGE_FEMME"));
                sag.setNom(rs.getString("NOM"));
                sag.setPrenom(rs.getString("PRENOM"));
                sag.setDate_naiss(rs.getDate("DATE_NAISSANCE"));
                sag.setAdresse(rs.getString("ADRESSE"));                
                sag.settel(rs.getInt("TEL"));
                sag.setSpecialite(rs.getString("SPECIALITE"));

                
            }
            conn.close();
            stm.close();
            return sag;
        }catch(Exception e){
            return null;
        }
    }
//                    ==================
//                        PROGRAMME
//                    ==================
    public static void insererPro(Programme pro){
        try{
            conn=getConnection();
            pstmet=conn.prepareStatement("insert into gestion_de_centre_de_sante_sage_femme.programme"
                    + "(ID_PROGRAMME,ID_SAGE_FEMME, DATE, HEURE_DEBUT, HEURE_FIN) values(?,?,?,?,?)");
            pstmet.setInt(1,pro.getId());
            pstmet.setInt(2,pro.getId_sf());
            pstmet.setString(3,String.valueOf(pro.getDate()));
            pstmet.setString(4,String.valueOf(pro.getHd()));
            pstmet.setString(5,String.valueOf(pro.getHf()));
            pstmet.executeUpdate();
            conn.close();
        }catch(Exception e){
            JOptionPane.showConfirmDialog(null,e.getMessage());
        }
    }
    public static ArrayList<Programme> AfficherPro(){
        ArrayList<Programme> list_pro=new ArrayList();
        Programme pro =null;
        try{
            conn=getConnection();
            stm=conn.createStatement();
            rs=stm.executeQuery("select * from gestion_de_centre_de_sante_sage_femme.programme");
            while(rs.next()){
                pro=new Programme();
                pro.setId(rs.getInt("ID_PROGRAMME"));
                pro.setId_sf(rs.getInt("ID_SAGE_FEMME"));
                pro.setDate(rs.getDate("DATE"));
                pro.setHd(rs.getDate("DATE_FABRICATION"));
                pro.setHf(rs.getDate("DATE_EXPIRATION"));
                
                
                list_pro.add(pro);
            }
            conn.close();
            stm.close();
        }catch(Exception e){
            JOptionPane.showConfirmDialog(null,e.getMessage());
        }return list_pro;
    }
    public static void SupprimerPro(Programme pro){
        try{
            conn = getConnection();
            stm = conn.createStatement();
            String delete="delete from gestion_de_centre_de_sante_sage_femme.programme where ID_PROGRAMME = '"+pro.getId()+"'";
            stm.executeUpdate(delete);
        }catch (Exception e){
            JOptionPane.showConfirmDialog(null, e.getMessage());
        }
    
    }
    public static void ModifierSag(Programme pro, int a){
        try{
            conn=getConnection();
            pstmet=conn.prepareStatement("update gestion_de_centre_de_sante_sage_femme.programme SET ID_SAGE_FEMME=?, DATE=?, DATE_FABRICATION=?, DATE_EXPIRATION=? where ID_PROGRAMME='"+a+"'");
            
            pstmet.setInt(1,pro.getId_sf());
            pstmet.setString(2,String.valueOf(pro.getDate()));            
            pstmet.setString(3,String.valueOf(pro.getHd()));
            pstmet.setString(4,String.valueOf(pro.getHf()));
            

            
            pstmet.executeUpdate();
            conn.close();
        }
        catch(Exception e){
            JOptionPane.showConfirmDialog(null, e.getMessage());
        }
    }
    public static Programme RechercherPro(int a){
        Programme pro = null;
        try{
            conn=getConnection();
            stm=conn.createStatement();
            rs=stm.executeQuery("select * from gestion_de_centre_de_sante_sage_femme.sage_femme where ID_SAGE_FEMME='"+a+"'");
            while(rs.next()){
                pro = new Programme();
//                sag.setId(rs.getInt("ID_SAGE_FEMME"));
                pro.setId_sf(rs.getInt("ID_SAGE_FEMME"));
                pro.setDate(rs.getDate("DATE"));
                pro.setHd(rs.getDate("DATE_FABRICATION"));
                pro.setHf(rs.getDate("DATE_EXPIRATION"));
                
            }
            conn.close();
            stm.close();
            return pro;
        }catch(Exception e){
            return null;
        }
    }
//                   ================
//                      UTILISATEUR
//                   ================
public static void insererUtil(Utilisateur util){
//        try{
//            conn=getConnection();
//            pstmet=conn.prepareStatement("insert into gestion_de_centre_de_sante_sage_femme.sage_femme"
//                    + "(ID_SAGE_FEMME,NOM, PRENOM, DATE_NAISSANCE, ADRESSE, TEL, SPECIALITE) values(?,?,?,?,?,?,?)");
//            pstmet.setInt(1,util.getId());
//            pstmet.setString(2,util.getNom());
//            pstmet.setString(3,util.getUsername());
//            pstmet.setString(4,String.valueOf(util.getDate_naiss()));
//            pstmet.setString(5,util.getAdresse());
//            pstmet.setInt(6,util.gettel());
//            pstmet.setString(7,util.getSpecialite());
//
//            
//            pstmet.executeUpdate();
//            conn.close();
//        }catch(Exception e){
//            JOptionPane.showConfirmDialog(null,e.getMessage());
//        }
//    }
//    public static ArrayList<SageFemme> AfficherSag(){
//        ArrayList<SageFemme> list_sag=new ArrayList();
//        SageFemme sag =null;
//        try{
//            conn=getConnection();
//            stm=conn.createStatement();
//            rs=stm.executeQuery("select * from gestion_de_centre_de_sante_sage_femme.sage_femme");
//            while(rs.next()){
//                sag=new SageFemme();
//                sag.setId(rs.getInt("ID_SAGE_FEMME"));
//                sag.setNom(rs.getString("NOM"));
//                sag.setPrenom(rs.getString("PRENOM"));
//                sag.setDate_naiss(rs.getDate("DATE_NAISSANCE"));
//                sag.setAdresse(rs.getString("ADRESSE"));
//                sag.settel(rs.getInt("TEL"));
//                sag.setSpecialite(rs.getString("SPECIALITE"));
//                
//                list_sag.add(sag);
//            }
//            conn.close();
//            stm.close();
//        }catch(Exception e){
//            JOptionPane.showConfirmDialog(null,e.getMessage());
//        }return list_sag;
//    }
//    public static void SupprimerSag(SageFemme sag){
//        try{
//            conn = getConnection();
//            stm = conn.createStatement();
//            String delete="delete from gestion_de_centre_de_sante_sage_femme.sage_femme where ID_SAGE_FEMME = '"+sag.getId()+"'";
//            stm.executeQuery(delete);
//        }catch (Exception e){
//            JOptionPane.showConfirmDialog(null, e.getMessage());
//        }
//    
//    }
//    public static void ModifierSag(SageFemme sag, int a){
//        try{
//            conn=getConnection();
//            pstmet=conn.prepareStatement("update gestion_de_centre_de_sante_sage_femme.sage_femme SET NOM=?, PRENOM=?, DATE_NAISSANCE=?, ADRESSE=?, TEL=?,SPECIALITE=? where ID_SAGE_FEMME='"+a+"'");
//            
//            pstmet.setString(1,sag.getNom());
//            pstmet.setString(2,sag.getPrenom());
//            pstmet.setString(3,String.valueOf(sag.getDate_naiss()));
//            pstmet.setString(4,sag.getAdresse());            
//            pstmet.setInt(5,sag.gettel());
//            pstmet.setString(6,sag.getSpecialite());
//
//            
//            pstmet.executeUpdate();
//            conn.close();
//        }
//        catch(Exception e){
//            JOptionPane.showConfirmDialog(null, e.getMessage());
//        }
//    }
//    public static SageFemme RechercherSag(int a){
//        SageFemme sag = null;
//        try{
//            conn=getConnection();
//            stm=conn.createStatement();
//            rs=stm.executeQuery("select * from gestion_de_centre_de_sante_sage_femme.sage_femme where ID_SAGE_FEMME='"+a+"'");
//            while(rs.next()){
//                sag = new SageFemme();
////                sag.setId(rs.getInt("ID_SAGE_FEMME"));
//                sag.setNom(rs.getString("NOM"));
//                sag.setPrenom(rs.getString("PRENOM"));
//                sag.setDate_naiss(rs.getDate("DATE_NAISSANCE"));
//                sag.setAdresse(rs.getString("ADRESSE"));                
//                sag.settel(rs.getInt("TEL"));
//                sag.setSpecialite(rs.getString("SPECIALITE"));
//
//                
//            }
//            conn.close();
//            stm.close();
//            return sag;
//        }catch(Exception e){
//            return null;
//        }
   }
//                    =================
//                      CONSULTATION
//                    =================
    public static void insererCon(Consultation con){
        try{
            conn=getConnection();
            pstmet=conn.prepareStatement("insert into gestion_de_centre_de_sante_sage_femme.consultation"
                    + "(ID_CONSULTATION,DATE_CONSULTATION, ID_PATIENT, ID_SAGE_FEMME, MALADIE) values(?,?,?,?,?)");
            pstmet.setInt(1,con.getId());
            pstmet.setString(2,String.valueOf(con.getDate()));
            pstmet.setInt(3,con.getId_pat());
            pstmet.setInt(4,con.getId_sf());
            pstmet.setString(5,con.getservice());

            
            pstmet.executeUpdate();
            conn.close();
        }catch(Exception e){
            JOptionPane.showConfirmDialog(null,e.getMessage());
        }
    }
    public static ArrayList<Consultation> AfficherCon(){
        ArrayList<Consultation> list_con=new ArrayList();
        Consultation con =null;
        try{
            conn=getConnection();
            stm=conn.createStatement();
            rs=stm.executeQuery("select * from gestion_de_centre_de_sante_sage_femme.consultation");
            while(rs.next()){
                con=new Consultation();
                con.setId(rs.getInt("ID_CONSULTATION"));
                con.setDate(rs.getDate("DATE_CONSULTATION"));
                con.setId_pat(rs.getInt("ID_PATIENT"));
                con.setId_sf(rs.getInt("ID_SAGE_FEMME"));
                con.setservice(rs.getString("MALADIE"));
                
                list_con.add(con);
            }
            conn.close();
            stm.close();
        }catch(Exception e){
            JOptionPane.showConfirmDialog(null,e.getMessage());
        }return list_con;
    }
    public static void SupprimerCon(Consultation con){
        try{
            conn = getConnection();
            stm = conn.createStatement();
            String delete="delete from gestion_de_centre_de_sante_sage_femme.consultation where ID_CONSULTATION = '"+con.getId()+"'";
            stm.executeUpdate(delete);
        }catch (Exception e){
            JOptionPane.showConfirmDialog(null, e.getMessage());
        }
    
    }
    public static void ModifierCon(Consultation con, int a){
        try{
            conn=getConnection();
            pstmet=conn.prepareStatement("update gestion_de_centre_de_sante_sage_femme.consultation SET DATE_CONSULTATION=?, ID_PATIENT=?, ID_SAGE_FEMME=?, ADRESSE=?, MALADIE=? where ID_CONSULTATION='"+a+"'");
            
            pstmet.setInt(1,con.getId());
            pstmet.setString(3,String.valueOf(con.getDate()));
            pstmet.setInt(4,con.getId_pat());            
            pstmet.setInt(5,con.getId_sf());
            pstmet.setString(6,con.getservice());

            
            pstmet.executeUpdate();
            conn.close();
        }
        catch(Exception e){
            JOptionPane.showConfirmDialog(null, e.getMessage());
        }
    }
    public static Consultation RechercherCon(int a){
        Consultation con = null;
        try{
            conn=getConnection();
            stm=conn.createStatement();
            rs=stm.executeQuery("select * from gestion_de_centre_de_sante_sage_femme.consultation where ID_CONSULTATION='"+a+"'");
            while(rs.next()){
                con = new Consultation();
//                sag.setId(rs.getInt("ID_SAGE_FEMME"));
                con.setDate(rs.getDate("DATE_CONSULTATION"));
                con.setId_pat(rs.getInt("ID_PATIENT"));
                con.setId_sf(rs.getInt("ID_SAGE_FEMME"));
                con.setservice(rs.getString("MALADIE"));                
            }
            conn.close();
            stm.close();
            return con;
        }catch(Exception e){
            return null;
        }
    }
}
