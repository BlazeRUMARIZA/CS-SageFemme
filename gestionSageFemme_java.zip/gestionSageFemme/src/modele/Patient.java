/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modele;
import java.util.Date;
/**
 *
 * @author rumariza
 */
public class Patient {
    private int id;
    private String nom;
    private String prenom;
    private java.util.Date date;
    private String adresse;
    private int tel;
    private String sexe;
    
    public void setId(int a){
        this.id=a;
    }
    public void setNom(String a){
        this.nom=a;
    }
    public void setPrenom(String a){
        this.prenom=a;
    }
    public void setDate(Date a){
        this.date=a;
    }
    public void setadresse(String a){
        this.adresse=a;
    }
    public void setTel(int a){
        this.tel=a;
    }
    public void setSexe(String a){
        this.sexe=a;
    }
    public int getId(){
        return id;
    }
    public String getInfo(){
        return String.valueOf(id)+" "+nom+" "+prenom;
    }
    public String getNom(){
        return nom;
    }
    public String getPrenom(){
        return prenom;
    }
    public java.util.Date getDatee(){
        return date;
    }
    public String getadresse(){
        return adresse;
    }
    public int getTel(){
        return tel;
    }
    public String getSexe(){
        return sexe;
    }
    public Patient(){
        
    }
    public Patient(int id,String nom,String prenom,java.util.Date date, String adresse, int tel,String se){
        this.adresse=adresse;
        this.date=date;
        this.nom=nom;
        this.id=id;
        this.sexe=se;
        this.tel=tel;
        this.prenom=prenom;
    }
}
