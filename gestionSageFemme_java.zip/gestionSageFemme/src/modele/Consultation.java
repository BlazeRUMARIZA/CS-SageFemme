/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modele;
import java.util.*;
public class Consultation {
    private int id;
    private Date date;
    private int id_pat;
    private int id_sf;
    private String service;
    
    
    public void setId(int a){
        this.id=a;
    }
    public void setDate(Date a){
        this.date=a;
    }
    public void setId_pat(int a){
        this.id_pat=a;
    }
    public void setId_sf(int a){
        this.id_sf=a;
    }
    public void setservice(String a){
        this.service=a;
    }
    
    public int getId(){
        return id;
    }
    public Date getDate(){
        return date;
    }
    public int getId_pat(){
        return id_pat;
    }
    public int getId_sf(){
        return id_sf;
    }
    public String getservice(){
        return service;
    }
    
    public Consultation(){
        
    }
    public Consultation(int id,Date dt,int id_pat,int id_sf,String service){
        this.date=dt;
        this.id=id;
        
        this.id_pat=id_pat;
        this.id_sf=id_sf;
        this.service=service;
    }
}
