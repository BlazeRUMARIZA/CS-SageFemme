/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modele;
import java.util.*;
/**
 *
 * @author rumariza
 */
public class Pharmacie {
    private int id;
    private String nom_medi;
    private String maladie;
    private Date date_fab;
    private Date date_exp;
    
    public void setId(int a){
        this.id=a;
    }
    public void setNom_medi(String a){
        this.nom_medi=a;
    }
    public void setMaladie(String a){
        this.maladie=a;
    }
    public void setDate_fab(Date a){
        this.date_fab=a;
    }
    public void setDate_exp(Date a){
        this.date_exp=a;
    }
    public int getId(){
        return id;
    }
    public String getNom_medi(){
        return nom_medi;
    }
    public String getMaladie(){
        return maladie;
    }
    public Date getDate_fab(){
        return date_fab;
    }
    public Date getDate_exp(){
        return date_exp;
    }
    public Pharmacie(){
        
    }
    public Pharmacie(int id,String nom,String maladie,Date fab,Date exp){
        this.id=id;
        this.date_exp=exp;
        this.date_fab=fab;
        this.nom_medi=nom;
        this.maladie=maladie;
    }
}
