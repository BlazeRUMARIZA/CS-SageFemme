/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modele;
/**
 *
 * @author rumariza
 */
public class Utilisateur {
 private int id;
 private String nom;
 private String username;
 private String motpasse;
 private String statut;
 private String bureau;
 
 public void setid(int a){
     this.id=a;
 }
 public void setNom(String a){
     this.nom=a;
 }
 public void setUsername(String a){
     this.username=a;
 }
 public void setMotpasse(String a){
     this.motpasse=a;
 }
 public void setStatut(String a){
     this.statut=a;
 }
 public void setBureau(String a){
     this.bureau=a;
 }
 public int getId(){
     return id;
 }
 public String getNom(){
     return nom;
 }
 public String getUsername(){
     return username;
 }
 public String getMotps(){
     return motpasse;
 }
 public String getStatut(){
     return statut;
 }
 public String getBureau(){
     return bureau;
 }
 public Utilisateur(){
     
 }
 public Utilisateur(int id,String nom,String username,String motpasse,String statut,String bureau){
     this.bureau=bureau;
     this.id=id;
     this.motpasse=motpasse;
     this.nom=nom;
     this.username=username;
     this.statut=statut;
 }
}
