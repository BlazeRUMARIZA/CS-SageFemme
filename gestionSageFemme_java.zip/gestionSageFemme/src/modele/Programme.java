/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modele;
import java.util.*;
import java.time.*;
/**
 *
 * @author rumariza
 */
public class Programme {
    private int id;
    private int id_sf;
    private Date date;
    private Date heure_d;
    private Date heure_f;
    
    public void setId(int a){
        this.id=a;
    }
    public void setId_sf(int a){
        this.id_sf=a;
    }
    public void setDate(Date a){
        this.date=a;
    }
    public void setHd(Date a){
        this.heure_d=a;
    }
    public void setHf(Date a){
        this.heure_f=a;
    }
    public int getId(){
        return id;
    }
    public int getId_sf(){
        return id_sf;
    }
    public Date getDate(){
        return date;
    }
    public Date getHd(){
        return heure_d;
    }
    public Date getHf(){
        return heure_f;
    }
    public Programme(){
        
    }
    public Programme(int id, int id_sf, Date date,Date hd,Date hf){
        this.date=date;
        this.heure_d=hd;
        this.heure_f=hf;
        this.id=id;
        this.id_sf=id_sf;
    }
}
