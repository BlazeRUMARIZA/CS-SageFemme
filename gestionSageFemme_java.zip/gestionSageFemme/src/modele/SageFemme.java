/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modele;
import java.util.Base64;
import java.util.Date;
import lombok.Setter;
import lombok.Getter;

public class SageFemme {
    @Setter @Getter
    private int id;
    @Setter @Getter
    private String nom;
    @Setter @Getter
    private String prenom;
    @Setter @Getter
    private java.util.Date date_naiss;
    @Setter @Getter
    private String adresse;
    @Setter @Getter
    private int tel;
    @Setter @Getter
    private String specialite;
    @Setter @Getter
    private Base64 photo;
    public void setId(int a){
        this.id=a;
    }
    public void setNom(String a){
        this.nom=a;
    }
    public void setPrenom(String a){
        this.prenom=a;
    }
    public void setDate_nais(Date a){
        this.date_naiss=a;
    }
    public void setAdresse(String a){
        this.adresse=a;
    }
    public void settel(int a){
        this.tel=a;
    }
    public void setSpecialite(String a){
        this.specialite=a;
    }
    public void setPhoto(Base64 a){
        this.photo=a;
    }
    
    public int getId(){
        return id;
    }
    public String getNom(){
        return nom;
    }
    public String getPrenom(){
        return prenom;
    }
    public Date getDate_nais(){
        return date_naiss;
    }
    public String getAdresse(){
        return adresse;
    }
    public int gettel(){
        return tel;
    }
    public String getInfo(){
        return String.valueOf(id)+" "+nom+" "+prenom;
    }
    public String getSpecialite(){
        return specialite;
    }
    public Base64 getPhoto(){
        return photo;
    }
    public SageFemme(){
        
    }
    public SageFemme(int id,String nom,String prenom, Date date_naiss,String adresse,int tel,String specialite){
        this.nom=nom;
        this.adresse=adresse;
        this.date_naiss=date_naiss;
        this.id=id;
        this.prenom=prenom;
       
        this.specialite=specialite;
        this.tel=tel;
    }
}
