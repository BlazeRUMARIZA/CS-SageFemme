/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vue;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.event.*;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
import modele.*;
import controller.*;
import gestionsagefemme.*;
import java.util.Date;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.io.*;
import com.toedter.calendar.JDateChooser;
import javax.swing.filechooser.FileNameExtensionFilter;
/**
 *
 * @author rumariza
 */
public class FormUtilisateur extends JFrame implements ActionListener{
    JLabel lid,lnom,lusername,lmotps,lstatut,lbureau;
    JTextField fid,fnom,fusername,fmotps,fr;
    JComboBox fstatut,fbureau;
    String[] li_sta={"administrateur systeme","Directeur General","Directeur RH","Directeur Finance","Receptioniste"};
    String[] li_bur={"centre des donnees","Administration","Direction RH","Direction Finance","Reception"};
    JButton save,disp,del,upd,rech;
    DefaultTableModel model;
    public FormUtilisateur(){
        lid = new JLabel ("Id");
        lid.setBounds(30,30,100,30);
        this.getContentPane().add(lid);
        
        fid = new JTextField ();
        fid.setBounds(150,30,200,30);
        this.getContentPane().add(fid);
        
        lnom = new JLabel ("Nom");
        lnom.setBounds(30,80,100,30);
        this.getContentPane().add(lnom);
        
        fr= new JTextField("");
        fr.setBounds(360, 30, 80, 30);
        this.getContentPane().add(fr);
        
        rech = new JButton ("Rechercher");
        rech.addActionListener(this);
        rech.setBounds(460, 30, 100, 30);
        this.getContentPane().add(rech);
        
        fnom = new JTextField ();
        fnom.setBounds(150,80,200,30);
        this.getContentPane().add(fnom);
        
        lusername = new JLabel ("Username");
        lusername.setBounds(30,130,100,30);
        this.getContentPane().add(lusername);
        
        fusername = new JTextField ();
        fusername.setBounds(150,130,200,30);
        this.getContentPane().add(fusername);
        
        lmotps = new JLabel ("Mot de Passe");
        lmotps.setBounds(30,180,100,30);
        this.getContentPane().add(lmotps);
        
        fmotps = new JTextField ();
        fmotps.setBounds(150,180,200,30);
        this.getContentPane().add(fmotps);
        
        lstatut = new JLabel ("Statut");
        lstatut.setBounds(30,230,100,30);
        this.getContentPane().add(lstatut);
        
        fstatut = new JComboBox (li_sta);
        fstatut.setBounds(150,230,100,30);
        this.getContentPane().add(fstatut);
        
        lbureau = new JLabel ("Bureau");
        lbureau.setBounds(30,280,100,30);
        this.getContentPane().add(lbureau);
        
        fbureau = new JComboBox (li_bur);
        fbureau.setBounds(150,280,100,30);
        this.getContentPane().add(fbureau);
        
        save = new JButton ("Ajouter");
        save.addActionListener(this);
        save.setBounds(20, 330, 100, 30);
        this.getContentPane().add(save);
        
        disp = new JButton ("Afficher");
        disp.addActionListener(this);
        disp.setBounds(130, 330, 100, 30);
        this.getContentPane().add(disp);
        
        upd = new JButton ("Modifier");
        upd.addActionListener(this);
        upd.setBounds(240, 330, 100, 30);
        this.getContentPane().add(upd);
        
        del = new JButton ("Effacer");
        del.addActionListener(this);
        del.setBounds(350, 330, 100, 30);
        this.getContentPane().add(del);
        
        model = new DefaultTableModel ();
        model.addColumn("ID");
        model.addColumn("NOM ET PRENOM");
        model.addColumn("USERNAME");
        model.addColumn("STATUT");
        model.addColumn("BUREAU");
        
        
        this.setLayout(null);
    }
    public void actionPerformed(ActionEvent e){
        
    }
}
