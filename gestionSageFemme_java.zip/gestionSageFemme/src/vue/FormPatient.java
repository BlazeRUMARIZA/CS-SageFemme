/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vue;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.event.*;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
import modele.*;
import controller.*;
//import bonteoliver.*;
import java.util.Date;
import java.time.*;
import java.time.format.DateTimeFormatter;
import com.toedter.calendar.JDateChooser;

public class FormPatient extends JFrame implements ActionListener{
    JLabel l1,l2,l3,l4,l5,l6,l7;
    JTextField f1,f2,f3,f5,f6,fr;
    JDateChooser f4;
    JRadioButton f,m;
    ButtonGroup a;
    JButton save,disp,upd,del,rech,menu;
    Patient pat = null;
    DefaultTableModel model;
    ArrayList<Patient> list_pat = new ArrayList();
    JTable tab_pat;
    
    public FormPatient(){
        l1 = new JLabel("ID");
        l1.setBounds(30, 30, 150, 30);
        this.getContentPane().add(l1);
        
        f1 = new JTextField("");
        f1.setBounds(200, 30, 150, 30);
        this.getContentPane().add(f1);
        
        fr= new JTextField("");
        fr.setBounds(360, 30, 80, 30);
        this.getContentPane().add(fr);
        
        rech = new JButton ("Rechercher");
        rech.addActionListener(this);
        rech.setBounds(460, 30, 100, 30);
        this.getContentPane().add(rech);
        
        menu = new JButton ("Menu");
        menu.addActionListener(this);
        menu.setBounds(570, 30, 80, 30);
        this.getContentPane().add(menu);
        
        l2 = new JLabel("Nom");
        l2.setBounds(30, 80, 150, 30);
        this.getContentPane().add(l2);
        
        f2 = new JTextField("");
        f2.setBounds(200, 80, 150, 30);
        this.getContentPane().add(f2);
        
        l3 = new JLabel("Prenom");
        l3.setBounds(30, 130, 150, 30);
        this.getContentPane().add(l3);
        
        f3 = new JTextField("");
        f3.setBounds(200, 130, 150, 30);
        this.getContentPane().add(f3);
        
        l4 = new JLabel("Date");
        l4.setBounds(30, 180, 150, 30);
        this.getContentPane().add(l4);
        
        f4=new JDateChooser ();
        f4.setDateFormatString("yyyy-MM-dd");
        f4.setBounds(200,180,150,30);
        this.getContentPane().add(f4);
        Date dt = f4.getDate();
        
        l5 = new JLabel("Adresse");
        l5.setBounds(30, 230, 150, 30);
        this.getContentPane().add(l5);
        
        f5 = new JTextField("");
        f5.setBounds(200, 230, 150, 30);
        this.getContentPane().add(f5);
        
        l6 = new JLabel("Telephone");
        l6.setBounds(30, 280, 150, 30);
        this.getContentPane().add(l6);
        
        f6 = new JTextField("");
        f6.setBounds(200, 280, 150, 30);
        this.getContentPane().add(f6);
        
        l7 = new JLabel("Gerne");
        l7.setBounds(30, 330, 150, 30);
        this.getContentPane().add(l7);
        
        f = new JRadioButton("Femme");
        f.setBounds(200, 330, 80, 30);
        this.getContentPane().add(f);
        
        m = new JRadioButton("Homme");
        m.setBounds(300, 330, 80, 30);
        this.getContentPane().add(m);
        
        a = new ButtonGroup();
        a.add(f);
        a.add(m);
        
        save = new JButton ("Ajouter");
        save.addActionListener(this);
        save.setBounds(20, 380, 100, 30);
        this.getContentPane().add(save);
        
        disp = new JButton ("Afficher");
        disp.addActionListener(this);
        disp.setBounds(130, 380, 100, 30);
        this.getContentPane().add(disp);
        
        upd = new JButton ("Modifier");
        upd.addActionListener(this);
        upd.setBounds(240, 380, 100, 30);
        this.getContentPane().add(upd);
        
        del = new JButton ("Effacer");
        del.addActionListener(this);
        del.setBounds(350, 380, 100, 30);
        this.getContentPane().add(del);
        
        model = new DefaultTableModel ();
        model.addColumn("ID");
        model.addColumn("NOM");
        model.addColumn("PRENOM");
        model.addColumn("DATE");
        model.addColumn("ADRESSE");
        model.addColumn("TELEPHONE");
        model.addColumn("SEXE");
        
        this.setLayout(null);
    }
    public void actionPerformed(ActionEvent e){
        if(e.getSource() == save){
            int id = Integer.valueOf(f1.getText());
            String nom = f2.getText();
            String prenom =f3.getText();
            java.util.Date LadateTech = (java.util.Date) f4.getDate();
             LocalDate localDate = LadateTech.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            java.sql.Date sqlDate = java.sql.Date.valueOf(localDate);
            String add = f5.getText();
            int tel = Integer.valueOf(f6.getText());
            String s = "";
            if(f.isSelected()){
                s= f.getText();
            }else if(m.isSelected()){
                s= m.getText();
            }
            pat = new Patient(id,nom,prenom,sqlDate,add,tel,s);
            Factory.insererPat(pat);
            
        }else if (e.getSource() == disp){
            afficher();
        }else if (e.getSource() == del){
                       int re=Integer.valueOf(fr.getText());
           if(pat != null){
               String msg = "Vous voulez vraiment "+pat.getNom();
               int conf = JOptionPane.showConfirmDialog(null,msg);
               if(conf== 0){
                   Factory.SupprimerPat(pat);
                   afficher();
               }
           } 
        }else if(e.getSource() == upd){
           int re=Integer.valueOf(fr.getText());
            String nom = f2.getText();
            String prenom =f3.getText();
            java.util.Date LadateTech = (java.util.Date) f4.getDate();
             LocalDate localDate = LadateTech.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            java.sql.Date sqlDate = java.sql.Date.valueOf(localDate);
            String add = f5.getText();
            int tel = Integer.valueOf(f6.getText());
            String s = "";
            if(f.isSelected()){
                s= f.getText();
            }else if(m.isSelected()){
                s= m.getText();
            }
              pat = new Patient(re,nom,prenom,sqlDate,add,tel,s);
                Factory.ModifierPat(pat,re);
            afficher();
        
        }else if(e.getSource() == rech){
            int re= Integer.valueOf(fr.getText());
            pat = Factory.RechercherPat(re);
            if(pat != null){
//                int asd = Integer.valueOf(f6);
                f2.setText(pat.getNom());
                f3.setText(pat.getPrenom());
                f4.setDate(pat.getDatee());
                f5.setText(pat.getadresse());
                f6.setText(String.valueOf(pat.getTel()));
//                f7.setText(pat.getSexe());
                if(pat.getSexe().equalsIgnoreCase(f.getText())){
                    f.setSelected(true);
                }else {
                    m.setSelected(true);
                }
            }
        }else if(e.getSource() == menu){
            
            Frommenu m = new Frommenu();
            m.setTitle("Menu General de Gestion de Centre de Sante des Sage-Femme");
                    m.setVisible(true);
                    setVisible(false);
        }
        
    }
    public void afficher(){
        model.setRowCount(0);
        list_pat=Factory.AfficherPat();
        for(Patient pa: list_pat){
            model.addRow(new Object[]{
            pa.getId(),pa.getNom(),pa.getPrenom(),pa.getDatee(),pa.getadresse(),pa.getTel(),pa.getSexe()
            });
        }
        tab_pat = new JTable(model);
        JScrollPane p = new JScrollPane(tab_pat);
        p.setBounds(360,80,400,200);
        this.getContentPane().add(p);
}
}
