/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vue;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.event.*;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
import modele.*;
import controller.*;
import gestionsagefemme.*;
import java.util.Date;
import java.time.*;
import java.time.format.DateTimeFormatter;
import com.toedter.calendar.JDateChooser;


/**
 *
 * @author rumariza
 */
public class interfaceUtilisateur extends JFrame implements ActionListener {
    JLabel label1,label2,label3,label4,label5,label6,label7;
    JTextField field1;
    JPasswordField field2;
    JButton button1,button2;
    public interfaceUtilisateur(){
        label1=new JLabel ("Nom d'Utilisateur");
            label1.setBounds(70,100,150,30);
            this.getContentPane().add(label1);
            
            field1=new JTextField ("");
            field1.setBounds(240,100,150,30);
            this.getContentPane().add(field1);
            
            label2=new JLabel ("Mot de Passe");
            label2.setBounds(70,160,150,30);
            this.getContentPane().add(label2);
            
            label3=new JLabel ();
            label3.setBounds(70,260,150,30);
            this.getContentPane().add(label3);
            
            field2=new JPasswordField ("");
            field2.setBounds(240,160,150,30);
            this.getContentPane().add(field2);
            
            button1 = new JButton ("Se connecter");
            button1.setBounds(120, 220, 100, 30);
            button1.addActionListener(this);
            this.getContentPane().add(button1);
            
            button2 = new JButton ("Annuler");
            button2.setBounds(260, 220, 100, 30);
            button2.addActionListener(this);
            this.getContentPane().add(button2);
            
            this.setLayout(null);
}
    public void actionPerformed(ActionEvent e){
        if(e.getSource() == button1){
        
        
        if(e.getSource()==button1){
        String nom= field1.getText();
        String passe= String.valueOf(field2.getPassword());
        
        Factory.SeConnecter(nom, passe);
        Frommenu frm = new Frommenu();
        frm.setVisible(true);
        setVisible(false);
        frm.setTitle("Menu General de Gestion de Centre de Sante des Sage-Femme");
        }else{
        label3.setText("Le nom d'utilisateur ou mot de passe est incorrect");
        label3.setForeground(new java.awt.Color(255, 0, 0));
        label3.setFont(new java.awt.Font("Liberation Sans", 1, 18));
        
        interfaceUtilisateur in= new interfaceUtilisateur ();
        
        }
        }
    }
    public interfaceUtilisateur leave() {
//         if (e.getSource() == button1){
             interfaceUtilisateur interuti = new interfaceUtilisateur();
            interuti.setVisible(false);
            return null;
//         }
             
    }
}
