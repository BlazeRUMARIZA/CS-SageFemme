/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vue;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.event.*;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
import modele.*;
import controller.*;
import gestionsagefemme.*;
import java.util.Date;
import java.time.*;
import java.time.format.DateTimeFormatter;
import com.toedter.calendar.JDateChooser;
/**
 *
 * @author rumariza
 */
public class FormPharmacie extends JFrame implements ActionListener{
    JLabel lid,lnom_medi,lmaladie,ldate_fab,ldate_exp;
    JTextField fid,fnom_medi,fmaladie,fr;
    JDateChooser dt_fb,dt_exp;
    JButton save,disp,upd,del,rech,menu;
    Pharmacie pha = null;
    DefaultTableModel model;
    ArrayList<Pharmacie> list_pha = new ArrayList();
    JTable tab_pha;
    
    public FormPharmacie(){
        lid= new JLabel ("Id");
        lid.setBounds(30,30,150,30);
        this.getContentPane().add(lid);
        
        fid = new JTextField ("");
        fid.setBounds(200,30,150,30);
        this.getContentPane().add(fid);
        
        fr = new JTextField ("");
        fr.setBounds(370,30,100,30);
        this.getContentPane().add(fr);
        
        lnom_medi= new JLabel("Medicament");
        lnom_medi.setBounds(30, 80, 150, 30);
        this.getContentPane().add(lnom_medi);
        
        fnom_medi = new JTextField ("");
        fnom_medi.setBounds(200,80,150,30);
        this.getContentPane().add(fnom_medi);
        
        lmaladie= new JLabel ("Service");
        lmaladie.setBounds(30,130,150,30);
        this.getContentPane().add(lmaladie);
        
        fmaladie = new JTextField ("");
        fmaladie.setBounds(200,130,150,30);
        this.getContentPane().add(fmaladie);
        
        ldate_fab= new JLabel ("Date Fabrication");
        ldate_fab.setBounds(30,180,150,30);
        this.getContentPane().add(ldate_fab);
        
        dt_fb= new JDateChooser();
        dt_fb.setDateFormatString("yyyy-MM-dd");
        dt_fb.setBounds(200,180,150,30);
        this.getContentPane().add(dt_fb);
        Date Ladate= dt_fb.getDate();
        
        ldate_exp= new JLabel ("Date Expiration");
        ldate_exp.setBounds(30,230,150,30);
        this.getContentPane().add(ldate_fab);
        
        dt_exp= new JDateChooser();
        dt_exp.setDateFormatString("yyyy-MM-dd");
        dt_exp.setBounds(200,230,150,30);
        this.getContentPane().add(dt_exp);
        Date Ladate_exp= dt_exp.getDate();
        
        save=new JButton ("Ajouter");
        save.addActionListener(this);
        save.setBounds(20, 280, 100, 30);
        this.getContentPane().add(save);
        
        disp=new JButton ("Afficher");
        disp.addActionListener(this);
        disp.setBounds(130, 280, 100, 30);
        this.getContentPane().add(disp);
        
        upd=new JButton ("Modidier");
        upd.addActionListener(this);
        upd.setBounds(240, 280, 100, 30);
        this.getContentPane().add(upd);
        
        del=new JButton ("Supprime");
        del.addActionListener(this);
        del.setBounds(350, 280, 100, 30);
        this.getContentPane().add(del);
        
        rech=new JButton ("Recherche");
        rech.addActionListener(this);
        rech.setBounds(480, 30, 100, 30);
        this.getContentPane().add(rech);
        
        menu=new JButton ("Menu");
        menu.addActionListener(this);
        menu.setBounds(570, 30, 100, 30);
        this.getContentPane().add(menu);
        
        model = new DefaultTableModel ();
        model.addColumn("ID");
        model.addColumn("MEDICAMENT");
        model.addColumn("MALADIE");
        model.addColumn("DATE FABRICATION");
        model.addColumn("DATE EXPIRATION");
        
        this.setLayout(null);
    }
    public void actionPerformed(ActionEvent e){
        if(e.getSource()==save){
            int id = Integer.valueOf(fid.getText());
            String medi = fnom_medi.getText();
            String mala = fmaladie.getText();
            java.util.Date LadateTech = (java.util.Date) dt_fb.getDate();
             LocalDate localDate = LadateTech.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            java.sql.Date sqlDate = java.sql.Date.valueOf(localDate);
            java.util.Date LadateTech_a = (java.util.Date) dt_exp.getDate();
             LocalDate localDate_a = LadateTech_a.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            java.sql.Date sqlDate_a = java.sql.Date.valueOf(localDate_a);
            Pharmacie pha = new Pharmacie(id,medi,mala,sqlDate,sqlDate_a);
            Factory.insererPha(pha);
        }else if(e.getSource() == disp){
            Afficher();
        }else if(e.getSource()== del){
            if(pha != null){
               String msg = "Vous voulez vraiment "+pha.getNom_medi();
               int conf = JOptionPane.showConfirmDialog(null,msg);
               if(conf== 0){
                   Factory.SupprimerPha(pha);
                   Afficher();
               }
        }
        }else if(e.getSource() == upd){
            int re=Integer.valueOf(fr.getText());
            String medi = fnom_medi.getText();
            String mala =fmaladie.getText();
            java.util.Date LadateTech = (java.util.Date) dt_fb.getDate();
             LocalDate localDate = LadateTech.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            java.sql.Date sqlDate = java.sql.Date.valueOf(localDate);
            java.util.Date LadateTech_a = (java.util.Date) dt_exp.getDate();
             LocalDate localDate_a = LadateTech_a.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            java.sql.Date sqlDate_a = java.sql.Date.valueOf(localDate_a);
            Pharmacie pha = new Pharmacie(re,medi,mala,sqlDate,sqlDate_a);
            
            pha = new Pharmacie(re,medi,mala,sqlDate,sqlDate_a);
                Factory.ModifierPha(pha,re);
            Afficher();
        }else if(e.getSource() == rech){
            int re= Integer.valueOf(fr.getText());
            pha = Factory.RechercherPha(re);
            if(pha != null){
//                int asd = Integer.valueOf(f6);
                fnom_medi.setText(pha.getNom_medi());
                fmaladie.setText(pha.getMaladie());
                dt_fb.setDate(pha.getDate_fab());
                dt_exp.setDate(pha.getDate_exp());
               
                }
            }else if(e.getSource() == menu){
            
            Frommenu m = new Frommenu();
                        m.setTitle("Menu General de Gestion de Centre de Sante des Sage-Femme");

                    m.setVisible(true);
                    setVisible(false);
        }
        }
      
    
    public void Afficher(){
        model.setRowCount(0);
        list_pha=Factory.AfficherPha();
        for(Pharmacie ph: list_pha){
            model.addRow(new Object[]{
            ph.getId(),ph.getNom_medi(),ph.getMaladie(),ph.getDate_fab(),ph.getDate_exp()
            });
        }
        tab_pha = new JTable(model);
        JScrollPane p = new JScrollPane(tab_pha);
        p.setBounds(360,80,400,200);
        this.getContentPane().add(p);
    }
}
