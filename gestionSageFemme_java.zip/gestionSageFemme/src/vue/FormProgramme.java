/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vue;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.event.*;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
import modele.*;
import controller.*;
//import bonteoliver.*;
import java.util.Date;
import java.time.LocalTime;
import java.time.*;
import java.time.LocalTime;
import org.xml.sax.
import java.time.format.DateTimeFormatter;
import com.toedter.calendar.JDateChooser;
import java.time.format.DateTimeFormatter;
//import com.jtattoo.
/**
 *
 * @author rumariza
 */
public class FormProgramme extends JFrame implements ActionListener{
    JLabel l1,l2,l3,l4,l5;
    JTextField f1,fr;
    JComboBox f2;
    JDateChooser f3,f4,f5;
        ArrayList<Programme> list_pro = new ArrayList();
    ArrayList<SageFemme> list_sag = new ArrayList();
    Programme pro= null;
    int index_sa=0;
    JButton save,disp,del,upd,rech,menu;
    JSpinner ff4,ff5;
    
    public FormProgramme(){
        l1 = new JLabel ("ID PROGRAMME");
        l1.setBounds(30, 30, 150, 30);
        this.getContentPane().add(l1);
        
        f1 = new JTextField ("");
        f1.setBounds(200, 30, 150, 30);
        this.getContentPane().add(f1);
        
        fr = new JTextField ("");
        fr.setBounds(360, 30, 100, 30);
        this.getContentPane().add(fr);
        
        l2 = new JLabel ("Sage Femme");
        l2.setBounds(30, 80, 150, 30);
        this.getContentPane().add(l2);
        
        f2=new JComboBox();
        list_sag=Factory.AfficherSag();
        for(SageFemme sa: list_sag){
            f2.addItem(sa.getInfo());
        }
        f2.addItemListener(new ItemListener(){
        public void itemStateChanged(ItemEvent e){
            index_sa= f2.getSelectedIndex();
        }
        });
        f2.setBounds(200, 80, 150, 30);
        this.getContentPane().add(f2);
        
        l3 = new JLabel ("Date");
        l3.setBounds(30, 130, 150, 30);
        this.getContentPane().add(l3);
        
        f3 = new JDateChooser ();
        f3.setDateFormatString("yyyy-MM-dd");
        f3.setBounds(200, 130, 150, 30);
        this.getContentPane().add(f3);
        
        l4 = new JLabel ("Heure Debut");
        l4.setBounds(30, 180, 150, 30);
        this.getContentPane().add(l4);
        
        
//        ff4 = new JSpinner(new LocalTimeSpinnerModel(LocalTime.now(),LocalTime.MIN,LocalTime.MAX,LocalTime.of(0, 1)));
//        JSpinner.DateEditor timeEditor =new JSpinner.DateEditor(ff4, "HH:mm:ss");
//        ff4.setEditor(timeEditor);
////        ff4.setValue();
//        ff4.setBounds(200, 130, 150, 30);
//        this.getContentPane().add(ff4);
        
        f4 = new JDateChooser ();
        f4.setDateFormatString("HH:mm:ss");
        f4.setBounds(200, 180, 150, 30);
        f4.setDate(new Date());
        this.getContentPane().add(f4);
        
        l5 = new JLabel ("Heure Fin");
        l5.setBounds(30, 230, 150, 30);
        this.getContentPane().add(l5);
        
        f5 = new JDateChooser ();
        f5.setDateFormatString("HH:mm:ss");
        f5.setBounds(200, 230, 150, 30);
        f5.setDate(new Date());
        
        this.getContentPane().add(f5);
        
//        ff5 = new JSpinner(new SpinnerDateModel());
//        JSpinner.DateEditor timeEditor1 =new JSpinner.DateEditor(ff5, "HH:mm:ss");
//        ff5.setEditor(timeEditor1);
//        ff5.setValue(LocalTime.now());
//        ff5.setBounds(200, 230, 150, 30);
//        this.getContentPane().add(ff5);
        
        save = new JButton ("Ajouter");
        save.addActionListener(this);
        save.setBounds(20, 280, 100, 30);
        this.getContentPane().add(save);
        
        disp = new JButton ("Afficher");
        disp.addActionListener(this);
        disp.setBounds(130, 280, 100, 30);
        this.getContentPane().add(disp);
        
        upd = new JButton ("Modifier");
        upd.addActionListener(this);
        upd.setBounds(240, 280, 100, 30);
        this.getContentPane().add(upd);
        
        del = new JButton ("Ajouter");
        del.addActionListener(this);
        del.setBounds(350, 280, 100, 30);
        this.getContentPane().add(del);
        
        rech = new JButton ("Rechercher");
        rech.addActionListener(this);
        rech.setBounds(470, 30, 100, 30);
        this.getContentPane().add(rech);
        
        menu=new JButton ("Menu");
        menu.addActionListener(this);
        menu.setBounds(570, 30, 80, 30);
        this.getContentPane().add(menu);
        
        this.setLayout(null);
    }
    public void actionPerformed(ActionEvent e){
              if(e.getSource()==save){
//                  int id = Integer.valueOf(f1.getText());
//                  int id_sa= list_sag.get(index_sa).getId();
//                  java.util.Time dt =  f3.
//             LocalDate localDate = dt.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
//            java.sql.Date sqlDate = java.sql.Date.valueOf(localDate);
//        
             java.time.LocalTime hd =  f4.;
            LocalTime localDatea= hd.toInstant().atZone(ZoneId.systemDefault()).toLocalTime();
            java.sql.Time sqlDatea = java.sql.Time.valueOf(localDatea);

            java.util.LocalTime hf =  f5.getTime();
             LocalTime localDateb = hf.toInstant().atZone(ZoneId.systemDefault()).toLocalTime();
            java.sql.Time sqlDateb = java.sql.Time.valueOf(localDateb);
                  
              }else if(e.getSource() == disp){
                  
              }else if(e.getSource() == upd){
                  
              }else if(e.getSource() == rech){
                  
              }else if(e.getSource() == del){
                  
              }else if(e.getSource() == menu){
//            FormProgramme f = new FormProgramme();
            
            Frommenu m = new Frommenu();
                        m.setTitle("Menu General de Gestion de Centre de Sante des Sage-Femme");

                    m.setVisible(true);
                    setVisible(false);
        }
            }
}
