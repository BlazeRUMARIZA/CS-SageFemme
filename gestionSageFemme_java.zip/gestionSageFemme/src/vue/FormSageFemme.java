/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vue;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.event.*;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
import modele.*;
import controller.*;
import gestionsagefemme.*;
import java.util.Date;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.io.*;
import com.toedter.calendar.JDateChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

public class FormSageFemme extends JFrame implements ActionListener{
    JLabel lid,lnom,lprenom,ldt_naiss,ladresse,ltel,lspecialite,lphoto;
    JTextField fid,fnom,fprenom,fadresse,fspecialite,ftel,fr;
    JDateChooser fdt_naiss;
    JFileChooser fphoto;
    JButton save,disp,del,rech,upd,menu;
    SageFemme sag = null;
    ArrayList<SageFemme> list_sag = new ArrayList();
    DefaultTableModel model;
    JTable tab_sag;
    
    public FormSageFemme(){
        lid=new JLabel ("Id-SageFemme");
        lid.setBounds(30, 30, 150, 30);
        this.getContentPane().add(lid);
        
        fid=new JTextField ("");
        fid.setBounds(200, 30, 150, 30);
        this.getContentPane().add(fid);
        
        fr=new JTextField ("");
        fr.setBounds(360, 30, 100, 30);
        this.getContentPane().add(fr);
        
        lnom=new JLabel ("Nom");
        lnom.setBounds(30, 80, 150, 30);
        this.getContentPane().add(lnom);
        
        fnom=new JTextField ("");
        fnom.setBounds(200, 80, 150, 30);
        this.getContentPane().add(fnom);
        
        lprenom=new JLabel ("Prenom");
        lprenom.setBounds(30, 130, 150, 30);
        this.getContentPane().add(lprenom);
        
        fprenom=new JTextField ("");
        fprenom.setBounds(200, 130, 150, 30);
        this.getContentPane().add(fprenom);
        
        ldt_naiss=new JLabel ("Date Naissance");
        ldt_naiss.setBounds(30, 180, 150, 30);
        this.getContentPane().add(ldt_naiss);
        
        fdt_naiss= new JDateChooser();
        fdt_naiss.setDateFormatString("yyyy-MM-dd");
        fdt_naiss.setBounds(200, 180, 150, 30);
        this.getContentPane().add(fdt_naiss);
        
        ladresse=new JLabel ("Adresse");
        ladresse.setBounds(30, 230, 150, 30);
        this.getContentPane().add(ladresse);
        
        fadresse=new JTextField ("");
        fadresse.setBounds(200, 230, 150, 30);
        this.getContentPane().add(fadresse);
        
        ltel=new JLabel ("Telephone");
        ltel.setBounds(30, 280, 150, 30);
        this.getContentPane().add(ltel);
        
        ftel=new JTextField ("");
        ftel.setBounds(200, 280, 150, 30);
        this.getContentPane().add(ftel);
        
        lspecialite=new JLabel ("Specialite");
        lspecialite.setBounds(30, 330, 150, 30);
        this.getContentPane().add(lspecialite);
        
        fspecialite=new JTextField ("");
        fspecialite.setBounds(200, 330, 150, 30);
        this.getContentPane().add(fspecialite);
        
       
        
//        lphoto = new JLabel ("Photo");
//        lphoto.setBounds(30, 380, 150, 30);
//        this.getContentPane().add(lphoto);
//        
        
        
        
        
//        fphoto=new JFileChooser ("");
//        JFrame frame= new JFrame("Selectionner un photo");
//        FileNameExtensionFilter filter = new FileNameExtensionFilter("Images","jpg","png","gif");
//        fphoto.setFileFilter(filter);
//        int resu=fphoto.showOpenDialog(frame);
//        if(resu == JFileChooser.APPROVE_OPTION){
//            java.io.File selectedFile = fphoto.getSelectedFile();
//            String nomphoto = selectedFile.getName();
//            try(InputStream photoInputStream = new java.io.FileInputStream(selectedFile)){
////                uploadPhotoTobd(nomphoto,photoInputStream);
//}catch(IOException e){
//                        
//                        }
//            }
//        fphoto.setBounds(200, 380, 150, 30);
//        this.getContentPane().add(fphoto);

        save=new JButton ("Ajouter");
        save.addActionListener(this);
        save.setBounds(20, 430, 100, 30);
        this.getContentPane().add(save);
        
        disp=new JButton ("Afficher");
        disp.addActionListener(this);
        disp.setBounds(130, 430, 100, 30);
        this.getContentPane().add(disp);
        
        upd=new JButton ("Modifier");
        upd.addActionListener(this);
        upd.setBounds(240, 430, 100, 30);
        this.getContentPane().add(upd);
        
        del=new JButton ("Supprimer");
        del.addActionListener(this);
        del.setBounds(350, 430, 100, 30);
        this.getContentPane().add(del);
        
        rech=new JButton ("Rechercher");
        rech.addActionListener(this);
        rech.setBounds(460, 30, 100, 30);
        this.getContentPane().add(rech);
        
        menu=new JButton ("Menu");
        menu.addActionListener(this);
        menu.setBounds(570, 30, 80, 30);
        this.getContentPane().add(menu);
        
        model = new DefaultTableModel();
        model.addColumn("ID");
        model.addColumn("Nom");
        model.addColumn("Prenom");
        model.addColumn("Date Naissance");
        model.addColumn("Adresse");
        model.addColumn("Telephone");
        model.addColumn("Specialite");
this.setLayout(null);
//            
        }
//        byte photoByte = convertInputStreamToByteArray(photoInputStream);
//        Blob photoBlob = conn.createBlob;
//        photoBlob.setBytes(1, photoBytes);
        
        
    
    public void actionPerformed(ActionEvent e){
        if(e.getSource() == save){
            int id = Integer.valueOf(fid.getText());
            String nom = fnom.getText();
            String prenom = fprenom.getText();
            java.util.Date LadateTech = (java.util.Date) fdt_naiss.getDate();
             LocalDate localDate = LadateTech.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            java.sql.Date sqlDate = java.sql.Date.valueOf(localDate);
            String add= fadresse.getText();
            int tel = Integer.valueOf(fadresse.getText());
            String spec = fspecialite.getText();
            sag = new SageFemme(id,nom,prenom,sqlDate,add,tel,spec);
            Factory.insererSag(sag);
            
        }else if(e.getSource() == disp){
            Afficher();
        }else if(e.getSource()== upd){
            int re = Integer.valueOf(fr.getText());
            String nom = fnom.getText();
            String prenom = fprenom.getText();
            java.util.Date LadateTech = (java.util.Date) fdt_naiss.getDate();
             LocalDate localDate = LadateTech.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            java.sql.Date sqlDate = java.sql.Date.valueOf(localDate);
            String add= fadresse.getText();
            int tel = Integer.valueOf(ftel.getText());
            String spec = fspecialite.getText();
            sag = new SageFemme(re,nom,prenom,sqlDate,add,tel,spec);  
            Factory.ModifierSag(sag, re);
            Afficher();
        }else if(e.getSource() == del){
            if(sag != null){
               String msg = "Vous voulez vraiment "+sag.getNom();
               int conf = JOptionPane.showConfirmDialog(null,msg);
               if(conf== 0){
                   Factory.SupprimerSag(sag);
                   Afficher();
               }
           } 
        }else if(e.getSource() == rech){
            int re = Integer.valueOf(fr.getText());
            sag = Factory.RechercherSag(re);
            if(sag != null){
                fnom.setText(sag.getNom());
                fprenom.setText(sag.getPrenom());
                fdt_naiss.setDate(sag.getDate_nais());
                fadresse.setText(sag.getAdresse());
                ftel.setText(String.valueOf(sag.gettel()));
                fspecialite.setText(sag.getSpecialite());
                
                
            }
        }else if(e.getSource() == menu){
//            FormSageFemme f = new FormSageFemme();
            
            Frommenu m = new Frommenu();
                        m.setTitle("Menu General de Gestion de Centre de Sante des Sage-Femme");

                    m.setVisible(true);
                    setVisible(false);
        }
        
    }
    public void Afficher(){
        model.setRowCount(0);
        list_sag=Factory.AfficherSag();
        for(SageFemme sa: list_sag){
            model.addRow(new Object[]{
            sa.getId(),sa.getNom(),sa.getPrenom(),sa.getDate_naiss(),sa.getAdresse(),sa.gettel(),sa.getSpecialite()
            });
        }
        tab_sag=new JTable(model);
        JScrollPane p=new JScrollPane(tab_sag);
        p.setBounds(360,80,500,100);
        this.getContentPane().add(p);
    }
    
}
