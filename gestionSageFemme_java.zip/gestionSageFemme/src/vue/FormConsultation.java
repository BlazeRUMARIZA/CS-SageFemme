/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vue;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
//import javax.swing.table.*;
import javax.swing.event.*;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
import modele.*;
import controller.*;
import gestionsagefemme.*;
import java.util.Date;
import java.time.*;
import java.time.format.DateTimeFormatter;
import com.toedter.calendar.JDateChooser;


public class FormConsultation extends JFrame implements ActionListener{
    JLabel lid,ldate,lid_pat,lid_sf,lservice;
    JTextField fid,fid1;
    JDateChooser fdate;
    JComboBox fid_pat,fid_sf,fservice;
    String[] service={"Soins prenataux","Accouchement","Soins Pastnatals","Planning Familiale","Soins gynecologues","Education et Promotion de sante"}; 
    JButton save,disp,rech,upd,del,menu;
    ArrayList<Patient> list_pat = new ArrayList();
    ArrayList<SageFemme> list_sag = new ArrayList();
    ArrayList<Consultation> list_cons = new ArrayList();
    int index_pat=0, index_sage=0;
    Consultation con = null;
    DefaultTableModel model;
    JTable tab_con;
    public FormConsultation(){
        lid = new JLabel ("Id_Consultation");
        lid.setBounds(30, 30, 150, 30);
        this.getContentPane().add(lid);
        
        ldate = new JLabel ("Date Consultation");
        ldate.setBounds(30, 80, 150, 30);
        this.getContentPane().add(ldate);
        
        lid_pat = new JLabel ("Patient");
        lid_pat.setBounds(30, 130, 150, 30);
        this.getContentPane().add(lid_pat);
        
        lid_sf = new JLabel ("Sage-Femme");
        lid_sf.setBounds(30, 180, 150, 30);
        this.getContentPane().add(lid_sf);
        
        lservice = new JLabel ("Service");
        lservice.setBounds(30, 230, 150, 30);
        this.getContentPane().add(lservice);
        
        fid = new JTextField ("");
        fid.setBounds(200,30,150,30);
        this.getContentPane().add(fid);
        
        fdate = new JDateChooser();
        fdate.setDateFormatString("yyyy-MM-dd");
        fdate.setBounds(200, 80, 150, 30);
        this.getContentPane().add(fdate);
        
        fid_pat = new JComboBox();
        list_pat = Factory.AfficherPat();
        for(Patient pat: list_pat){
            fid_pat.addItem(pat.getInfo());
        }
        fid_pat.addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent e){
                index_pat = fid_pat.getSelectedIndex();
            }
        });
        fid_pat.setBounds(200, 130, 150, 30);
        this.getContentPane().add(fid_pat);
        
        fid_sf = new JComboBox();
        list_sag = Factory.AfficherSag();
        for(SageFemme sage: list_sag){
            fid_sf.addItem(sage.getInfo());
        }
        fid_sf.addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent e){
                index_sage = fid_sf.getSelectedIndex();
            }
        });
        fid_sf.setBounds(200, 180, 150, 30);
        this.getContentPane().add(fid_sf);
        
        fservice = new JComboBox(service);
        fservice.setBounds(200, 230, 150, 30);
        this.getContentPane().add(fservice);
        
        save= new JButton ("Ajouter");
        save.setBounds(30, 280, 100, 30);
        save.addActionListener(this);
        this.getContentPane().add(save);
        
        disp= new JButton ("Afficher");
        disp.setBounds(150, 280, 100, 30);
        disp.addActionListener(this);
        this.getContentPane().add(disp);
        
        upd= new JButton ("Modifier");
        upd.setBounds(270, 280, 100, 30);
        upd.addActionListener(this);
        this.getContentPane().add(upd);
        
        del= new JButton ("Effacer");
        del.setBounds(390, 280, 100, 30);
        del.addActionListener(this);
        this.getContentPane().add(del);
        
        fid1 = new JTextField ("");
        fid1.setBounds(370,30,150,30);
        this.getContentPane().add(fid1);
        
        rech = new JButton ("Rechercher");
        rech.setBounds(530, 30, 100, 30);
        rech.addActionListener(this);
        this.getContentPane().add(rech);
        
        menu = new JButton ("Menu");
        menu.setBounds(640, 30, 80, 30);
        menu.addActionListener(this);
        this.getContentPane().add(menu);
        
        model = new DefaultTableModel();
        model.addColumn("ID");
        model.addColumn("Date");
        model.addColumn("Patient");
        model.addColumn("Sage-Femme");
        model.addColumn("Service");

        this.setLayout(null);
        
    }
    public void actionPerformed(ActionEvent e){
        if(e.getSource() == save){
            int cons= Integer.valueOf(fid.getText());
            int pat=list_pat.get(index_pat).getId();
            int sag= list_sag.get(index_sage).getId();
            
             java.util.Date LadateTech =  fdate.getDate();
             LocalDate localDate = LadateTech.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            java.sql.Date sqlDate = java.sql.Date.valueOf(localDate);
            String ser = fservice.getSelectedItem().toString();
            
            con = new Consultation(cons,sqlDate,pat,sag,ser);
            Factory.insererCon(con);
            Afficher(); 
        }else if(e.getSource() == disp){
            Afficher();
        }else if (e.getSource() == upd){
          int rech= Integer.valueOf(fid1.getText());
            int pat=list_pat.get(index_pat).getId();
            int sag= list_sag.get(index_sage).getId();
            
             java.util.Date LadateTech =  fdate.getDate();
             LocalDate localDate = LadateTech.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            java.sql.Date sqlDate = java.sql.Date.valueOf(localDate);
            String ser = fservice.getSelectedItem().toString();
            
            con = new Consultation(rech,sqlDate,pat,sag,ser);
            Factory.ModifierCon(con,rech);
            Afficher();   
        }else if(e.getSource() == rech){
            int rech= Integer.valueOf(fid1.getText());
            con = Factory.RechercherCon(rech);
            if(con != null){
                fdate.setDate(con.getDate());
                fid_pat.setSelectedItem(affPat(con.getId_pat()));
                fid_sf.setSelectedItem(affsag(con.getId_sf()));
            }

        }else if(e.getSource() == del){
            if(con != null){
               String msg = "Vous voulez vraiment le consultation N"+con.getId();
               int conf = JOptionPane.showConfirmDialog(null,msg);
               if(conf== 0){
                   Factory.SupprimerCon(con);
                   Afficher();
               }
           } 
        }else if(e.getSource() == menu){
            
            Frommenu m = new Frommenu();
            m.setTitle("Menu General de Gestion de Centre de Sante des Sage-Femme");
                    m.setVisible(true);
                    setVisible(false);
        }
    }
    public void Afficher(){
        model.setRowCount(0);
        list_cons=Factory.AfficherCon();
        for(Consultation c: list_cons){
            model.addRow(new Object[]{
            c.getId(),c.getDate(),affPat(c.getId_pat()),affsag(c.getId_sf()),c.getservice()
            });
        }
        tab_con= new JTable(model);
        JScrollPane p = new JScrollPane(tab_con);
        p.setBounds(370,80,500,100);
        this.getContentPane().add(p);
    }
    String affPat(int num){
        String nume="";
        for(Patient t: list_pat){
            if(t.getId() == num){
                nume=t.getInfo();
                break;
            }
        }
        return nume;
    }
    String affsag(int num){
        String nume="";
        for(SageFemme t: list_sag){
            if(t.getId() == num){
                nume=t.getInfo();
                break;
            }
        }
        return nume;
    }
}
