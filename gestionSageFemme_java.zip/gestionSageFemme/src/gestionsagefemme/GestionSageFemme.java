
package gestionsagefemme;
import vue.*;
/**
 *
 * @author rumariza
 */
public class GestionSageFemme {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
//        System.out.println("Rumariza Blaze");
        interfaceUtilisateur interuti = new interfaceUtilisateur();
            interuti.setSize(500,500);
        interuti.setTitle("Se connecter a votre Compte");
        interuti.setVisible(true);
        
        
        
        
        
//        interuti.leave(e);`
        
    }
    
}
